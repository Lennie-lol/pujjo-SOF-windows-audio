/* SPDX-License-Identifier: BSD-3-Clause */
/*
 * Copyright 2026 The SOF Authors
 */

#include <sof/ext_manifest.h>

