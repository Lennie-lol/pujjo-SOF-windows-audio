/* SPDX-License-Identifier: (GPL-2.0-only OR BSD-3-Clause) */
/*
 * This file is provided under a dual BSD/GPLv2 license.  When using or
 * redistributing this file, you may do so under either license.
 *
 * Copyright(c) 2022 Intel Corporation
 */

#ifndef __INCLUDE_SOUND_SOF_IPC4_HEADER_H__
#define __INCLUDE_SOUND_SOF_IPC4_HEADER_H__

#include <linux/types.h>
#include <uapi/sound/sof/abi.h>

/* maximum message size for mailbox Tx/Rx */
#define SOF_IPC4_MSG_MAX_SIZE			4096

/** \addtogroup sof_uapi uAPI
 *  SOF uAPI specification.
 *  @{
 */

/**
 * struct sof_ipc4_msg - Placeholder of an IPC4 message
 * @header_u64:		IPC4 header as single u64 number
 * @primary:		Primary, mandatory part of the header
 * @extension:		Extended part of the header, if not used it should be
 *			set to 0
 * @data_size:		Size of data in bytes pointed by @data_ptr
 * @data_ptr:		Pointer to the optional payload of a message
 */
struct sof_ipc4_msg {
	union {
		u64 header_u64;
		struct {
			u32 primary;
			u32 extension;
		};
	};

	size_t data_size;
	void *data_ptr;
};

/**
 * struct sof_ipc4_tuple - Generic type/ID and parameter tuple
 * @type:		type/ID
 * @size:		size of the @value array in bytes
 * @value:		value for the given type
 */
struct sof_ipc4_tuple {
	uint32_t type;
	uint32_t size;
	uint32_t value[];
} __packed;

/*
 * IPC4 messages have two 32 bit identifier made up as follows :-
 *
 * header - msg type, msg id, msg direction ...
 * extension - extra params such as msg data size in mailbox
 *
 * These are sent at the start of the IPC message in the mailbox. Messages
 * should not be sent in the doorbell (special exceptions for firmware).
 */

/*
 * IPC4 primary header bit allocation for messages
 * bit 0-23:	message type specific
 * bit 24-28:	type:	enum sof_ipc4_global_msg if target is SOF_IPC4_FW_GEN_MSG
 *			enum sof_ipc4_module_type if target is SOF_IPC4_MODULE_MSG
 * bit 29:	response - sof_ipc4_msg_dir
 * bit 30:	target - enum sof_ipc4_msg_target
 * bit 31:	reserved, unused
 */

/* Value of target field - must fit into 1 bit */
enum sof_ipc4_msg_target {
	/* Global FW message */
	SOF_IPC4_FW_GEN_MSG,

	/* Module message */
	SOF_IPC4_MODULE_MSG
};

/* Value of type field - must fit into 5 bits */
enum sof_ipc4_global_msg {
	SOF_IPC4_GLB_BOOT_CONFIG,
	SOF_IPC4_GLB_ROM_CONTROL,
	SOF_IPC4_GLB_IPCGATEWAY_CMD,

	/* 3 .. 12: RESERVED - do not use */

	SOF_IPC4_GLB_PERF_MEASUREMENTS_CMD = 13,
	SOF_IPC4_GLB_CHAIN_DMA,

	SOF_IPC4_GLB_LOAD_MULTIPLE_MODULES,
	SOF_IPC4_GLB_UNLOAD_MULTIPLE_MODULES,

	/* pipeline settings */
	SOF_IPC4_GLB_CREATE_PIPELINE,
	SOF_IPC4_GLB_DELETE_PIPELINE,
	SOF_IPC4_GLB_SET_PIPELINE_STATE,
	SOF_IPC4_GLB_GET_PIPELINE_STATE,
	SOF_IPC4_GLB_GET_PIPELINE_CONTEXT_SIZE,
	SOF_IPC4_GLB_SAVE_PIPELINE,
	SOF_IPC4_GLB_RESTORE_PIPELINE,

	/*
	 * library loading
	 *
	 * Loads library (using Code Load or HD/A Host Output DMA)
	 */
	SOF_IPC4_GLB_LOAD_LIBRARY,
	/*
	 * Prepare the host DMA channel for library loading, must be followed by
	 * a SOF_IPC4_GLB_LOAD_LIBRARY message as the library loading step
	 */
	SOF_IPC4_GLB_LOAD_LIBRARY_PREPARE,

	SOF_IPC4_GLB_INTERNAL_MESSAGE,

	/* Notification (FW to SW driver) */
	SOF_IPC4_GLB_NOTIFICATION,

	/* 28 .. 30: RESERVED - do not use */

	SOF_IPC4_GLB_ENTER_GDB = 31,
	SOF_IPC4_GLB_TYPE_LAST,
};

/* Value of response field - must fit into 1 bit */
enum sof_ipc4_msg_dir {
	SOF_IPC4_MSG_REQUEST,
	SOF_IPC4_MSG_REPLY,
};

enum sof_ipc4_pipeline_state {
	SOF_IPC4_PIPE_INVALID_STATE,
	SOF_IPC4_PIPE_UNINITIALIZED,
	SOF_IPC4_PIPE_RESET,
	SOF_IPC4_PIPE_PAUSED,
	SOF_IPC4_PIPE_RUNNING,
	SOF_IPC4_PIPE_EOS
};

/* Generic message fields (bit 24-30) */

/* encoded to header's msg_tgt field */
#define SOF_IPC4_MSG_TARGET_SHIFT		30
#define SOF_IPC4_MSG_TARGET_MASK		BIT(30)
#define SOF_IPC4_MSG_TARGET(x)			((x) << SOF_IPC4_MSG_TARGET_SHIFT)
#define SOF_IPC4_MSG_IS_MODULE_MSG(x)		((x) & SOF_IPC4_MSG_TARGET_MASK ? 1 : 0)

/* encoded to header's rsp field */
#define SOF_IPC4_MSG_DIR_SHIFT			29
#define SOF_IPC4_MSG_DIR_MASK			BIT(29)
#define SOF_IPC4_MSG_DIR(x)			((x) << SOF_IPC4_MSG_DIR_SHIFT)

/* encoded to header's type field */
#define SOF_IPC4_MSG_TYPE_SHIFT			24
#define SOF_IPC4_MSG_TYPE_MASK			GENMASK(28, 24)
#define SOF_IPC4_MSG_TYPE_SET(x)		(((x) << SOF_IPC4_MSG_TYPE_SHIFT) & \
						 SOF_IPC4_MSG_TYPE_MASK)
#define SOF_IPC4_MSG_TYPE_GET(x)		(((x) & SOF_IPC4_MSG_TYPE_MASK) >> \
						 SOF_IPC4_MSG_TYPE_SHIFT)

/* Global message type specific field definitions */

/* pipeline creation ipc msg */
#define SOF_IPC4_GLB_PIPE_INSTANCE_SHIFT	16
#define SOF_IPC4_GLB_PIPE_INSTANCE_MASK		GENMASK(23, 16)
#define SOF_IPC4_GLB_PIPE_INSTANCE_ID(x)	((x) << SOF_IPC4_GLB_PIPE_INSTANCE_SHIFT)

#define SOF_IPC4_GLB_PIPE_PRIORITY_SHIFT	11
#define SOF_IPC4_GLB_PIPE_PRIORITY_MASK		GENMASK(15, 11)
#define SOF_IPC4_GLB_PIPE_PRIORITY(x)		((x) << SOF_IPC4_GLB_PIPE_PRIORITY_SHIFT)

#define SOF_IPC4_GLB_PIPE_MEM_SIZE_SHIFT	0
#define SOF_IPC4_GLB_PIPE_MEM_SIZE_MASK		GENMASK(10, 0)
#define SOF_IPC4_GLB_PIPE_MEM_SIZE(x)		((x) << SOF_IPC4_GLB_PIPE_MEM_SIZE_SHIFT)

#define SOF_IPC4_GLB_PIPE_EXT_LP_SHIFT		0
#define SOF_IPC4_GLB_PIPE_EXT_LP_MASK		BIT(0)
#define SOF_IPC4_GLB_PIPE_EXT_LP(x)		((x) << SOF_IPC4_GLB_PIPE_EXT_LP_SHIFT)

#define SOF_IPC4_GLB_PIPE_EXT_CORE_ID_SHIFT	20
#define SOF_IPC4_GLB_PIPE_EXT_CORE_ID_MASK	GENMASK(23, 20)
#define SOF_IPC4_GLB_PIPE_EXT_CORE_ID(x)	((x) << SOF_IPC4_GLB_PIPE_EXT_CORE_ID_SHIFT)

#define SOF_IPC4_GLB_PIPE_PAYLOAD_SHIFT		29
#define SOF_IPC4_GLB_PIPE_PAYLOAD_MASK		BIT(29)
#define SOF_IPC4_GLB_PIPE_PAYLOAD(x)		((x) << SOF_IPC4_GLB_PIPE_PAYLOAD_SHIFT)

/* pipeline set state ipc msg */
#define SOF_IPC4_GLB_PIPE_STATE_ID_SHIFT		16
#define SOF_IPC4_GLB_PIPE_STATE_ID_MASK		GENMASK(23, 16)
#define SOF_IPC4_GLB_PIPE_STATE_ID(x)		((x) << SOF_IPC4_GLB_PIPE_STATE_ID_SHIFT)

#define SOF_IPC4_GLB_PIPE_STATE_SHIFT		0
#define SOF_IPC4_GLB_PIPE_STATE_MASK		GENMASK(15, 0)
#define SOF_IPC4_GLB_PIPE_STATE(x)		((x) << SOF_IPC4_GLB_PIPE_STATE_SHIFT)

/* pipeline set state IPC msg extension */
#define SOF_IPC4_GLB_PIPE_STATE_EXT_MULTI	BIT(0)

/* load library ipc msg */
#define SOF_IPC4_GLB_LOAD_LIBRARY_LIB_ID_SHIFT	16
#define SOF_IPC4_GLB_LOAD_LIBRARY_LIB_ID(x)	((x) << SOF_IPC4_GLB_LOAD_LIBRARY_LIB_ID_SHIFT)

/* chain dma ipc message */
#define SOF_IPC4_GLB_CHAIN_DMA_HOST_ID_SHIFT	0
#define SOF_IPC4_GLB_CHAIN_DMA_HOST_ID_MASK	GENMASK(4, 0)
#define SOF_IPC4_GLB_CHAIN_DMA_HOST_ID(x)	(((x) << SOF_IPC4_GLB_CHAIN_DMA_HOST_ID_SHIFT) & \
						 SOF_IPC4_GLB_CHAIN_DMA_HOST_ID_MASK)

#define SOF_IPC4_GLB_CHAIN_DMA_LINK_ID_SHIFT	8
#define SOF_IPC4_GLB_CHAIN_DMA_LINK_ID_MASK	GENMASK(12, 8)
#define SOF_IPC4_GLB_CHAIN_DMA_LINK_ID(x)	(((x) << SOF_IPC4_GLB_CHAIN_DMA_LINK_ID_SHIFT) & \
						 SOF_IPC4_GLB_CHAIN_DMA_LINK_ID_MASK)

#define SOF_IPC4_GLB_CHAIN_DMA_ALLOCATE_SHIFT	16
#define SOF_IPC4_GLB_CHAIN_DMA_ALLOCATE_MASK	BIT(16)
#define SOF_IPC4_GLB_CHAIN_DMA_ALLOCATE(x)	(((x) & 1) << SOF_IPC4_GLB_CHAIN_DMA_ALLOCATE_SHIFT)

#define SOF_IPC4_GLB_CHAIN_DMA_ENABLE_SHIFT	17
#define SOF_IPC4_GLB_CHAIN_DMA_ENABLE_MASK	BIT(17)
#define SOF_IPC4_GLB_CHAIN_DMA_ENABLE(x)	(((x) & 1) << SOF_IPC4_GLB_CHAIN_DMA_ENABLE_SHIFT)

#define SOF_IPC4_GLB_CHAIN_DMA_SCS_SHIFT	18
#define SOF_IPC4_GLB_CHAIN_DMA_SCS_MASK		BIT(18)
#define SOF_IPC4_GLB_CHAIN_DMA_SCS(x)		(((x) & 1) << SOF_IPC4_GLB_CHAIN_DMA_SCS_SHIFT)

#define SOF_IPC4_GLB_EXT_CHAIN_DMA_FIFO_SIZE_SHIFT 0
#define SOF_IPC4_GLB_EXT_CHAIN_DMA_FIFO_SIZE_MASK  GENMASK(24, 0)
#define SOF_IPC4_GLB_EXT_CHAIN_DMA_FIFO_SIZE(x)	   (((x) << \
						     SOF_IPC4_GLB_EXT_CHAIN_DMA_FIFO_SIZE_SHIFT) & \
						    SOF_IPC4_GLB_EXT_CHAIN_DMA_FIFO_SIZE_MASK)

enum sof_ipc4_channel_config {
	/* one channel only. */
	SOF_IPC4_CHANNEL_CONFIG_MONO,
	/* L & R. */
	SOF_IPC4_CHANNEL_CONFIG_STEREO,
	/* L, R & LFE; PCM only. */
	SOF_IPC4_CHANNEL_CONFIG_2_POINT_1,
	/* L, C & R; MP3 & AAC only. */
	SOF_IPC4_CHANNEL_CONFIG_3_POINT_0,
	/* L, C, R & LFE; PCM only. */
	SOF_IPC4_CHANNEL_CONFIG_3_POINT_1,
	/* L, R, Ls & Rs; PCM only. */
	SOF_IPC4_CHANNEL_CONFIG_QUATRO,
	/* L, C, R & Cs; MP3 & AAC only. */
	SOF_IPC4_CHANNEL_CONFIG_4_POINT_0,
	/* L, C, R, Ls & Rs. */
	SOF_IPC4_CHANNEL_CONFIG_5_POINT_0,
	/* L, C, R, Ls, Rs & LFE. */
	SOF_IPC4_CHANNEL_CONFIG_5_POINT_1,
	/* one channel replicated in two. */
	SOF_IPC4_CHANNEL_CONFIG_DUAL_MONO,
	/* Stereo (L,R) in 4 slots, 1st stream: [ L, R, -, - ] */
	SOF_IPC4_CHANNEL_CONFIG_I2S_DUAL_STEREO_0,
	/* Stereo (L,R) in 4 slots, 2nd stream: [ -, -, L, R ] */
	SOF_IPC4_CHANNEL_CONFIG_I2S_DUAL_STEREO_1,
	/* L, C, R, Ls, Rs & LFE., LS, RS */
	SOF_IPC4_CHANNEL_CONFIG_7_POINT_1,
};

enum sof_ipc4_interleaved_style {
	SOF_IPC4_CHANNELS_INTERLEAVED,
	SOF_IPC4_CHANNELS_NONINTERLEAVED,
};

enum sof_ipc4_sample_type {
	SOF_IPC4_MSB_INTEGER, /* integer with Most Significant Byte first */
	SOF_IPC4_LSB_INTEGER, /* integer with Least Significant Byte first */
};

struct sof_ipc4_audio_format {
	uint32_t sampling_frequency;
	uint32_t bit_depth;
	uint32_t ch_map;
	uint32_t ch_cfg; /* sof_ipc4_channel_config */
	uint32_t interleaving_style;
	uint32_t fmt_cfg; /* channels_count valid_bit_depth s_type */
} __packed __aligned(4);

#define SOF_IPC4_AUDIO_FORMAT_CFG_CHANNELS_COUNT_SHIFT	0
#define SOF_IPC4_AUDIO_FORMAT_CFG_CHANNELS_COUNT_MASK	GENMASK(7, 0)
#define SOF_IPC4_AUDIO_FORMAT_CFG_CHANNELS_COUNT(x)	\
	((x) & SOF_IPC4_AUDIO_FORMAT_CFG_CHANNELS_COUNT_MASK)
#define SOF_IPC4_AUDIO_FORMAT_CFG_V_BIT_DEPTH_SHIFT	8
#define SOF_IPC4_AUDIO_FORMAT_CFG_V_BIT_DEPTH_MASK	GENMASK(15, 8)
#define SOF_IPC4_AUDIO_FORMAT_CFG_V_BIT_DEPTH(x)	\
	(((x) & SOF_IPC4_AUDIO_FORMAT_CFG_V_BIT_DEPTH_MASK) >> \
	 SOF_IPC4_AUDIO_FORMAT_CFG_V_BIT_DEPTH_SHIFT)
#define SOF_IPC4_AUDIO_FORMAT_CFG_SAMPLE_TYPE_SHIFT	16
#define SOF_IPC4_AUDIO_FORMAT_CFG_SAMPLE_TYPE_MASK	GENMASK(23, 16)
#define SOF_IPC4_AUDIO_FORMAT_CFG_SAMPLE_TYPE(x)	\
	(((x) & SOF_IPC4_AUDIO_FORMAT_CFG_SAMPLE_TYPE_MASK) >>  \
	 SOF_IPC4_AUDIO_FORMAT_CFG_SAMPLE_TYPE_SHIFT)

/* Module message type specific field definitions */

enum sof_ipc4_module_type {
	SOF_IPC4_MOD_INIT_INSTANCE,
	SOF_IPC4_MOD_CONFIG_GET,
	SOF_IPC4_MOD_CONFIG_SET,
	SOF_IPC4_MOD_LARGE_CONFIG_GET,
	SOF_IPC4_MOD_LARGE_CONFIG_SET,
	SOF_IPC4_MOD_BIND,
	SOF_IPC4_MOD_UNBIND,
	SOF_IPC4_MOD_SET_DX,
	SOF_IPC4_MOD_SET_D0IX,
	SOF_IPC4_MOD_ENTER_MODULE_RESTORE,
	SOF_IPC4_MOD_EXIT_MODULE_RESTORE,
	SOF_IPC4_MOD_DELETE_INSTANCE,

	SOF_IPC4_MOD_TYPE_LAST,
};

struct sof_ipc4_base_module_cfg {
	uint32_t cpc; /* the max count of Cycles Per Chunk processing */
	uint32_t ibs; /* input Buffer Size (in bytes)  */
	uint32_t obs; /* output Buffer Size (in bytes) */
	uint32_t is_pages; /* number of physical pages used */
	struct sof_ipc4_audio_format audio_fmt;
} __packed __aligned(4);

/* common module ipc msg */
#define SOF_IPC4_MOD_INSTANCE_SHIFT		16
#define SOF_IPC4_MOD_INSTANCE_MASK		GENMASK(23, 16)
#define SOF_IPC4_MOD_INSTANCE(x)		((x) << SOF_IPC4_MOD_INSTANCE_SHIFT)
#define SOF_IPC4_MOD_INSTANCE_GET(x)		(((x) & SOF_IPC4_MOD_INSTANCE_MASK) \
						 >> SOF_IPC4_MOD_INSTANCE_SHIFT)

#define SOF_IPC4_MOD_ID_SHIFT			0
#define SOF_IPC4_MOD_ID_MASK			GENMASK(15, 0)
#define SOF_IPC4_MOD_ID(x)			((x) << SOF_IPC4_MOD_ID_SHIFT)
#define SOF_IPC4_MOD_ID_GET(x)			(((x) & SOF_IPC4_MOD_ID_MASK) \
						 >> SOF_IPC4_MOD_ID_SHIFT)

/* init module ipc msg */
#define SOF_IPC4_MOD_EXT_PARAM_SIZE_SHIFT	0
#define SOF_IPC4_MOD_EXT_PARAM_SIZE_MASK	GENMASK(15, 0)
#define SOF_IPC4_MOD_EXT_PARAM_SIZE(x)		((x) << SOF_IPC4_MOD_EXT_PARAM_SIZE_SHIFT)

#define SOF_IPC4_MOD_EXT_PPL_ID_SHIFT		16
#define SOF_IPC4_MOD_EXT_PPL_ID_MASK		GENMASK(23, 16)
#define SOF_IPC4_MOD_EXT_PPL_ID(x)		((x) << SOF_IPC4_MOD_EXT_PPL_ID_SHIFT)

#define SOF_IPC4_MOD_EXT_CORE_ID_SHIFT		24
#define SOF_IPC4_MOD_EXT_CORE_ID_MASK		GENMASK(27, 24)
#define SOF_IPC4_MOD_EXT_CORE_ID(x)		((x) << SOF_IPC4_MOD_EXT_CORE_ID_SHIFT)

#define SOF_IPC4_MOD_EXT_DOMAIN_SHIFT		28
#define SOF_IPC4_MOD_EXT_DOMAIN_MASK		BIT(28)
#define SOF_IPC4_MOD_EXT_DOMAIN(x)		((x) << SOF_IPC4_MOD_EXT_DOMAIN_SHIFT)

#define SOF_IPC4_MOD_EXT_EXTENDED_INIT_SHIFT	29
#define SOF_IPC4_MOD_EXT_EXTENDED_INIT_MASK	BIT(29)
#define SOF_IPC4_MOD_EXT_EXTENDED_INIT(x)	((x) << SOF_IPC4_MOD_EXT_EXTENDED_SHIFT)

/*  bind/unbind module ipc msg */
#define SOF_IPC4_MOD_EXT_DST_MOD_ID_SHIFT	0
#define SOF_IPC4_MOD_EXT_DST_MOD_ID_MASK	GENMASK(15, 0)
#define SOF_IPC4_MOD_EXT_DST_MOD_ID(x)		((x) << SOF_IPC4_MOD_EXT_DST_MOD_ID_SHIFT)

#define SOF_IPC4_MOD_EXT_DST_MOD_INSTANCE_SHIFT	16
#define SOF_IPC4_MOD_EXT_DST_MOD_INSTANCE_MASK	GENMASK(23, 16)
#define SOF_IPC4_MOD_EXT_DST_MOD_INSTANCE(x)	((x) << SOF_IPC4_MOD_EXT_DST_MOD_INSTANCE_SHIFT)

#define SOF_IPC4_MOD_EXT_DST_MOD_QUEUE_ID_SHIFT	24
#define SOF_IPC4_MOD_EXT_DST_MOD_QUEUE_ID_MASK	GENMASK(26, 24)
#define SOF_IPC4_MOD_EXT_DST_MOD_QUEUE_ID(x)	((x) << SOF_IPC4_MOD_EXT_DST_MOD_QUEUE_ID_SHIFT)

#define SOF_IPC4_MOD_EXT_SRC_MOD_QUEUE_ID_SHIFT	27
#define SOF_IPC4_MOD_EXT_SRC_MOD_QUEUE_ID_MASK	GENMASK(29, 27)
#define SOF_IPC4_MOD_EXT_SRC_MOD_QUEUE_ID(x)	((x) << SOF_IPC4_MOD_EXT_SRC_MOD_QUEUE_ID_SHIFT)

#define MOD_ENABLE_LOG	6
#define MOD_SYSTEM_TIME	20

/* set module large config */
#define SOF_IPC4_MOD_EXT_MSG_SIZE_SHIFT		0
#define SOF_IPC4_MOD_EXT_MSG_SIZE_MASK		GENMASK(19, 0)
#define SOF_IPC4_MOD_EXT_MSG_SIZE(x)		((x) << SOF_IPC4_MOD_EXT_MSG_SIZE_SHIFT)

#define SOF_IPC4_MOD_EXT_MSG_PARAM_ID_SHIFT	20
#define SOF_IPC4_MOD_EXT_MSG_PARAM_ID_MASK	GENMASK(27, 20)
#define SOF_IPC4_MOD_EXT_MSG_PARAM_ID(x)	((x) << SOF_IPC4_MOD_EXT_MSG_PARAM_ID_SHIFT)

#define SOF_IPC4_MOD_EXT_MSG_LAST_BLOCK_SHIFT	28
#define SOF_IPC4_MOD_EXT_MSG_LAST_BLOCK_MASK	BIT(28)
#define SOF_IPC4_MOD_EXT_MSG_LAST_BLOCK(x)	((x) << SOF_IPC4_MOD_EXT_MSG_LAST_BLOCK_SHIFT)

#define SOF_IPC4_MOD_EXT_MSG_FIRST_BLOCK_SHIFT	29
#define SOF_IPC4_MOD_EXT_MSG_FIRST_BLOCK_MASK	BIT(29)
#define SOF_IPC4_MOD_EXT_MSG_FIRST_BLOCK(x)	((x) << SOF_IPC4_MOD_EXT_MSG_FIRST_BLOCK_SHIFT)

/* Init instance messagees */
#define SOF_IPC4_MOD_INIT_BASEFW_MOD_ID		0
#define SOF_IPC4_MOD_INIT_BASEFW_INSTANCE_ID	0

enum sof_ipc4_base_fw_params {
	SOF_IPC4_FW_PARAM_ENABLE_LOGS = 6,
	SOF_IPC4_FW_PARAM_FW_CONFIG,
	SOF_IPC4_FW_PARAM_HW_CONFIG_GET,
	SOF_IPC4_FW_PARAM_MODULES_INFO_GET,
	SOF_IPC4_FW_PARAM_LIBRARIES_INFO_GET = 16,
	SOF_IPC4_FW_PARAM_SYSTEM_TIME = 20,
	SOF_IPC4_FW_PARAM_MIC_PRIVACY_STATE_CHANGE = 35,
};

enum sof_ipc4_fw_config_params {
	SOF_IPC4_FW_CFG_FW_VERSION,
	SOF_IPC4_FW_CFG_MEMORY_RECLAIMED,
	SOF_IPC4_FW_CFG_SLOW_CLOCK_FREQ_HZ,
	SOF_IPC4_FW_CFG_FAST_CLOCK_FREQ_HZ,
	SOF_IPC4_FW_CFG_DMA_BUFFER_CONFIG,
	SOF_IPC4_FW_CFG_ALH_SUPPORT_LEVEL,
	SOF_IPC4_FW_CFG_DL_MAILBOX_BYTES,
	SOF_IPC4_FW_CFG_UL_MAILBOX_BYTES,
	SOF_IPC4_FW_CFG_TRACE_LOG_BYTES,
	SOF_IPC4_FW_CFG_MAX_PPL_COUNT,
	SOF_IPC4_FW_CFG_MAX_ASTATE_COUNT,
	SOF_IPC4_FW_CFG_MAX_MODULE_PIN_COUNT,
	SOF_IPC4_FW_CFG_MODULES_COUNT,
	SOF_IPC4_FW_CFG_MAX_MOD_INST_COUNT,
	SOF_IPC4_FW_CFG_MAX_LL_TASKS_PER_PRI_COUNT,
	SOF_IPC4_FW_CFG_LL_PRI_COUNT,
	SOF_IPC4_FW_CFG_MAX_DP_TASKS_COUNT,
	SOF_IPC4_FW_CFG_MAX_LIBS_COUNT,
	SOF_IPC4_FW_CFG_SCHEDULER_CONFIG,
	SOF_IPC4_FW_CFG_XTAL_FREQ_HZ,
	SOF_IPC4_FW_CFG_CLOCKS_CONFIG,
	SOF_IPC4_FW_CFG_RESERVED,
	SOF_IPC4_FW_CFG_POWER_GATING_POLICY,
	SOF_IPC4_FW_CFG_ASSERT_MODE,
	/* Reserved: 24 - 28 */
	SOF_IPC4_FW_CONTEXT_SAVE = 29,
	/* Reserved: 30 - 34 */
	SOF_IPC4_FW_CFG_SOF_INFO = 35,
};

struct sof_ipc4_fw_version {
	uint16_t major;
	uint16_t minor;
	uint16_t hotfix;
	uint16_t build;
} __packed;

/*
 * tuple based array for SOF specific information under SOF_IPC4_FW_CFG_SOF_INFO
 * tuple of fw_config
 */
enum ipc4_fw_sof_info_params {
	SOF_IPC4_SOF_CODEC_INFO,
};

/* Payload data for SOF_IPC4_MOD_SET_DX */
struct sof_ipc4_dx_state_info {
	/* core(s) to apply the change */
	uint32_t core_mask;
	/* core state: 0: put core_id to D3; 1: put core_id to D0 */
	uint32_t dx_mask;
} __packed __aligned(4);

enum sof_ipc4_hw_config_params {
	SOF_IPC4_HW_CFG_INTEL_MIC_PRIVACY_CAPS = 11,
};

#define SOF_IPC_INTEL_MIC_PRIVACY_VERSION_PTL	1

struct sof_ipc4_intel_mic_privacy_cap {
	uint32_t version;
	uint32_t capabilities_length;
	uint32_t capabilities[];
} __packed;

/* Reply messages */

/*
 * IPC4 primary header bit allocation for replies
 * bit 0-23:	status
 * bit 24-28:	type:	enum sof_ipc4_global_msg if target is SOF_IPC4_FW_GEN_MSG
 *			enum sof_ipc4_module_type if target is SOF_IPC4_MODULE_MSG
 * bit 29:	response - sof_ipc4_msg_dir
 * bit 30:	target - enum sof_ipc4_msg_target
 * bit 31:	reserved, unused
 */

#define SOF_IPC4_REPLY_STATUS			GENMASK(23, 0)

/* Notification messages */

/*
 * IPC4 primary header bit allocation for notifications
 * bit 0-15:	notification type specific
 * bit 16-23:	enum sof_ipc4_notification_type
 * bit 24-28:	SOF_IPC4_GLB_NOTIFICATION
 * bit 29:	response - sof_ipc4_msg_dir
 * bit 30:	target - enum sof_ipc4_msg_target
 * bit 31:	reserved, unused
 */

#define SOF_IPC4_MSG_IS_NOTIFICATION(x)		(SOF_IPC4_MSG_TYPE_GET(x) == \
						 SOF_IPC4_GLB_NOTIFICATION)

#define SOF_IPC4_NOTIFICATION_TYPE_SHIFT	16
#define SOF_IPC4_NOTIFICATION_TYPE_MASK		GENMASK(23, 16)
#define SOF_IPC4_NOTIFICATION_TYPE_GET(x)	(((x) & SOF_IPC4_NOTIFICATION_TYPE_MASK) >> \
						 SOF_IPC4_NOTIFICATION_TYPE_SHIFT)

#define SOF_IPC4_LOG_CORE_SHIFT			12
#define SOF_IPC4_LOG_CORE_MASK			GENMASK(15, 12)
#define SOF_IPC4_LOG_CORE_GET(x)		(((x) & SOF_IPC4_LOG_CORE_MASK) >> \
						 SOF_IPC4_LOG_CORE_SHIFT)

#define SOF_IPC4_FW_READY_LIB_RESTORED		BIT(15)

/* Value of notification type field - must fit into 8 bits */
enum sof_ipc4_notification_type {
	/* Phrase detected (notification from WoV module) */
	SOF_IPC4_NOTIFY_PHRASE_DETECTED = 4,
	/* Event from a resource (pipeline or module instance) */
	SOF_IPC4_NOTIFY_RESOURCE_EVENT,
	/* Debug log buffer status changed */
	SOF_IPC4_NOTIFY_LOG_BUFFER_STATUS,
	/* Timestamp captured at the link */
	SOF_IPC4_NOTIFY_TIMESTAMP_CAPTURED,
	/* FW complete initialization */
	SOF_IPC4_NOTIFY_FW_READY,
	/* Audio classifier result (ACA) */
	SOF_IPC4_NOTIFY_FW_AUD_CLASS_RESULT,
	/* Exception caught by DSP FW */
	SOF_IPC4_NOTIFY_EXCEPTION_CAUGHT,
	/* 11 is skipped by the existing cavs firmware */
	/* Custom module notification */
	SOF_IPC4_NOTIFY_MODULE_NOTIFICATION = 12,
	/* 13 is reserved - do not use */
	/* Probe notify data available */
	SOF_IPC4_NOTIFY_PROBE_DATA_AVAILABLE = 14,
	/* AM module notifications */
	SOF_IPC4_NOTIFY_ASYNC_MSG_SRVC_MESSAGE,

	SOF_IPC4_NOTIFY_TYPE_LAST,
};

enum sof_ipc4_resource_type {
	SOF_IPC4_MODULE_INSTANCE,
	SOF_IPC4_PIPELINE,
	SOF_IPC4_GATEWAY,
	SOF_IPC4_EDF_TASK,
	SOF_IPC4_INVALID_RESOURCE_TYPE,
};

enum sof_ipc4_event_type {
	/* Underrun detected by the Mixer */
	SOF_IPC4_MIXER_UNDERRUN_DETECTED = 1,
	/* Error caught during data processing */
	SOF_IPC4_PROCESS_DATA_ERROR = 3,
	/* Underrun detected by gateway. */
	SOF_IPC4_GATEWAY_UNDERRUN_DETECTED = 6,
	/* Overrun detected by gateway */
	SOF_IPC4_GATEWAY_OVERRUN_DETECTED,
};

/**
 * struct sof_ipc4_process_data_error_event_data - process data error event payload
 * @error_code: Error code returned by data processing function
 */
struct sof_ipc4_process_data_error_event_data {
	uint32_t error_code;
};

/**
 * struct sof_ipc4_mixer_underrun_event_data - mixer underrun event payload
 * @eos_flag: Indicates EndOfStream
 * @data_mixed: Data processed by module (in bytes)
 * @expected_data_mixed: Expected data to be processed (in bytes)
 */
struct sof_ipc4_mixer_underrun_event_data {
	uint32_t eos_flag;
	uint32_t data_mixed;
	uint32_t expected_data_mixed;
};

/**
 * union sof_ipc4_resource_event_data - resource event specific payload
 * @dws: Raw event data payload as six dwords
 * @process_data_error: SOF_IPC4_PROCESS_DATA_ERROR payload
 * @mixer_underrun: SOF_IPC4_MIXER_UNDERRUN_DETECTED payload
 */
union sof_ipc4_resource_event_data {
	uint32_t dws[6];
	struct sof_ipc4_process_data_error_event_data process_data_error;
	struct sof_ipc4_mixer_underrun_event_data mixer_underrun;
};

struct sof_ipc4_notify_resource_data {
	uint32_t resource_type;
	uint32_t resource_id;
	uint32_t event_type;
	uint32_t reserved;
	union sof_ipc4_resource_event_data data;
} __packed __aligned(4);

/*
 * The debug memory window contains up to 16 4kB large pages, where pages one to
 * fifteen are used for user slots and page zero contains slot descriptors:
 *
 *	------------------------
 *	| Page0  - descriptors |
 *	------------------------
 *	| Page1  - slot0       |
 *	------------------------
 *	| Page2  - slot1       |
 *	------------------------
 *	|         ...          |
 *	------------------------
 *	| Page14  - slot13     |
 *	------------------------
 *	| Page15  - slot14     |
 *	------------------------
 *
 * The slot descriptor is:
 * u32 res_id;
 * u32 type;
 * u32 vma;
 */

#define SOF_IPC4_DEBUG_PAGE_SIZE		0x1000
#define SOF_IPC4_DEBUG_SLOT_SIZE		SOF_IPC4_DEBUG_PAGE_SIZE
#define SOF_IPC4_DEBUG_PAGE0_SLOT_OFFSET	1024

/* Usable slots 0..14 (page 1..15) */
#define SOF_IPC4_MAX_DEBUG_SLOTS		15

/*
 * Descriptor 0-14: slot 0-14 (page 1-15)
 * Descriptor 15: partial slot at page 0 + 1024
 */
#define SOF_IPC4_MAX_DEBUG_DESCS		(SOF_IPC4_MAX_DEBUG_SLOTS + 1)
#define SOF_IPC4_DEBUG_DESCRIPTOR_SIZE		12 /* 3 x u32 */

/* Debug log slot types */
#define SOF_IPC4_DEBUG_SLOT_UNUSED		0x00000000
#define SOF_IPC4_DEBUG_SLOT_CRITICAL_LOG	0x54524300 /* byte 0: core ID */
#define SOF_IPC4_DEBUG_SLOT_DEBUG_LOG		0x474f4c00 /* byte 0: core ID */
#define SOF_IPC4_DEBUG_SLOT_GDB_STUB		0x42444700
#define SOF_IPC4_DEBUG_SLOT_TELEMETRY		0x4c455400
#define SOF_IPC4_DEBUG_SLOT_BROKEN		0x44414544

/**
 * struct sof_ipc4_notify_module_data - payload for module notification
 * @instance_id: instance ID of the originator module of the notification
 * @module_id: module ID of the originator of the notification
 * @event_id: module specific event id
 * @event_data_size: Size of the @event_data (if any) in bytes
 * @event_data: Optional notification data, module and notification dependent
 */
struct sof_ipc4_notify_module_data {
	uint16_t instance_id;
	uint16_t module_id;
	uint32_t event_id;
	uint32_t event_data_size;
	uint8_t event_data[];
} __packed __aligned(4);

/*
 * ALSA kcontrol change notification
 *
 * The event_id of struct sof_ipc4_notify_module_data is divided into two u16:
 *  upper u16: magic number for ALSA kcontrol types: 0xA15A
 *  lower u16: param_id of the control, which is the type of the control
 * The event_data contains the struct sof_ipc4_control_msg_payload of the control
 * which sent the notification.
 */
#define SOF_IPC4_NOTIFY_MODULE_EVENTID_SOF_MAGIC_MASK		GENMASK(31, 16)
#define SOF_IPC4_NOTIFY_MODULE_EVENTID_ALSA_MAGIC_VAL		0xA15A0000
#define SOF_IPC4_NOTIFY_MODULE_EVENTID_ALSA_PARAMID_MASK	GENMASK(15, 0)
#define SOF_IPC4_NOTIFY_MODULE_EVENTID_COMPR_MAGIC_VAL		0xC0C00000

/*
 * Macros for creating struct sof_ipc4_module_init_ext_init payload
 * with its associated data. ext_init payload should be the first
 * piece of payload following SOF_IPC4_MOD_INIT_INSTANCE msg, and its
 * existence is indicated with SOF_IPC4_MOD_EXT_EXTENDED-bit.
 *
 * The macros below apply to sof_ipc4_module_init_ext_init.word0
 */
#define SOF_IPC4_MOD_INIT_EXT_RTOS_DOMAIN_SHIFT	0
#define SOF_IPC4_MOD_INIT_EXT_RTOS_DOMAIN_MASK	BIT(0)
#define SOF_IPC4_MOD_INIT_EXT_RTOS_DOMAIN(x)	((x) << SOF_IPC4_MOD_INIT_EXT_RTOS_DOMAIN_SHIFT)

#define SOF_IPC4_MOD_INIT_EXT_GNA_USED_SHIFT	1
#define SOF_IPC4_MOD_INIT_EXT_GNA_USED_MASK	BIT(1)
#define SOF_IPC4_MOD_INIT_EXT_GNA_USED(x)	((x) << SOF_IPC4_MOD_INIT_EXT_GNA_USED_SHIFT)

#define SOF_IPC4_MOD_INIT_EXT_OBJ_ARRAY_SHIFT	2
#define SOF_IPC4_MOD_INIT_EXT_OBJ_ARRAY_MASK	BIT(2)
#define SOF_IPC4_MOD_INIT_EXT_DATA_ARRAY(x)	((x) << SOF_IPC4_MOD_INIT_EXT_OBJ_ARRAY_SHIFT)

struct sof_ipc4_module_init_ext_init {
	u32 word0;
	u32 rsvd1;
	u32 rsvd2;
} __packed __aligned(4);

/*
 * SOF_IPC4_MOD_EXT_EXTENDED payload may be followed by arbitrary
 * number of object array objects. SOF_IPC4_MOD_INIT_EXT_DATA_ARRAY
 * -bit indicates that an array object follows struct
 * sof_ipc4_module_init_ext_init.
 *
 * The object header's SOF_IPC4_MOD_INIT_EXT_OBJ_LAST-bit in struct
 * sof_ipc4_module_init_ext_object indicates if the array is continued
 * with another object. The header has also fields to identify the
 * object, SOF_IPC4_MOD_INIT_EXT_OBJ_ID, and to indicate the object's
 * size in 32-bit words, SOF_IPC4_MOD_INIT_EXT_OBJ_WORDS, not
 * including the header itself.
 *
 * The macros below apply to sof_ipc4_module_init_ext_object.header
 */
#define SOF_IPC4_MOD_INIT_EXT_OBJ_LAST_SHIFT	0
#define SOF_IPC4_MOD_INIT_EXT_OBJ_LAST_MASK	BIT(0)
#define SOF_IPC4_MOD_INIT_EXT_OBJ_LAST(x)	((x) << SOF_IPC4_MOD_INIT_EXT_OBJ_LAST_SHIFT)

#define SOF_IPC4_MOD_INIT_EXT_OBJ_ID_SHIFT	1
#define SOF_IPC4_MOD_INIT_EXT_OBJ_ID_MASK	GENMASK(15, 1)
#define SOF_IPC4_MOD_INIT_EXT_OBJ_ID(x)		((x) << SOF_IPC4_MOD_INIT_EXT_OBJ_ID_SHIFT)

#define SOF_IPC4_MOD_INIT_EXT_OBJ_WORDS_SHIFT	16
#define SOF_IPC4_MOD_INIT_EXT_OBJ_WORDS_MASK	GENMASK(31, 16)
#define SOF_IPC4_MOD_INIT_EXT_OBJ_WORDS(x)	((x) << SOF_IPC4_MOD_INIT_EXT_OBJ_WORDS_SHIFT)

struct sof_ipc4_module_init_ext_object {
	u32 header;
	u32 data[];
} __packed __aligned(4);

enum sof_ipc4_mod_init_ext_obj_id {
	SOF_IPC4_MOD_INIT_DATA_ID_INVALID = 0,
	SOF_IPC4_MOD_INIT_DATA_ID_DP_DATA,
	SOF_IPC4_MOD_INIT_DATA_ID_MODULE_DATA,
	SOF_IPC4_MOD_INIT_DATA_ID_MAX = SOF_IPC4_MOD_INIT_DATA_ID_MODULE_DATA,
};

/* DP module memory configuration data object for object array */
struct sof_ipc4_mod_init_ext_dp_memory_data {
	u32 domain_id;			/* userspace domain ID */
	u32 stack_bytes;		/* required stack size in bytes */
	u32 heap_bytes;		/* required heap size in bytes */
} __packed __aligned(4);

/*
 * This set of macros are very similar to the set above, but these are
 * for building payload to SOF_IPC4_GLB_CREATE_PIPELINE message.
 *
 * Macros for creating struct sof_ipc4_glb_pipe_payload payload with
 * its associated data. struct sof_ipc4_glb_pipe_payload should be the
 * first piece of payload following SOF_IPC4_GLB_CREATE_PIPELINE msg,
 * and its existence is indicated with SOF_IPC4_GLB_PIPE_PAYLOAD bit.
 *
 * The macros below apply to sof_ipc4_glb_pipe_payload.word0
 */
#define SOF_IPC4_GLB_PIPE_PAYLOAD_WORDS_SHIFT	0
#define SOF_IPC4_GLB_PIPE_PAYLOAD_WORDS_MASK	GENMASK(23, 0)
#define SOF_IPC4_GLB_PIPE_PAYLOAD_WORDS(x)	((x) << SOF_IPC4_GLB_PIPE_PAYLOAD_WORDS_SHIFT)

#define SOF_IPC4_GLB_PIPE_EXT_OBJ_ARRAY_SHIFT	24
#define SOF_IPC4_GLB_PIPE_EXT_OBJ_ARRAY_MASK	BIT(24)
#define SOF_IPC4_GLB_PIPE_EXT_OBJ_ARRAY(x)	((x) << SOF_IPC4_GLB_PIPE_EXT_OBJ_ARRAY_SHIFT)

struct sof_ipc4_glb_pipe_payload {
	u32 word0;
	u32 rsvd1;
	u32 rsvd2;
} __packed __aligned(4);

/*
 * SOF_IPC4_GLB_CREATE_PIPELINE payload may be followed by arbitrary
 * number of object array objects. SOF_IPC4_GLB_PIPE_EXT_OBJ_ARRAY-bit
 * indicates that an array object follows struct
 * sof_ipc4_glb_pipe_payload.
 *
 * The object header's SOF_IPC4_GLB_PIPE_EXT_OBJ_LAST-bit in struct
 * sof_ipc4_glb_pipe_ext_object indicates if the array is continued
 * with another object. The header has also fields to identify the
 * object, SOF_IPC4_GLB_PIPE_EXT_OBJ_ID, and to indicate the object's
 * size in 32-bit words, SOF_IPC4_GLB_PIPE_EXT_OBJ_WORDS, not
 * including the header itself.
 *
 * The macros below apply to sof_ipc4_glb_pipe_ext_object.header
 */
#define SOF_IPC4_GLB_PIPE_EXT_OBJ_LAST_SHIFT	0
#define SOF_IPC4_GLB_PIPE_EXT_OBJ_LAST_MASK	BIT(0)
#define SOF_IPC4_GLB_PIPE_EXT_OBJ_LAST(x)	((x) << SOF_IPC4_GLB_PIPE_EXT_OBJ_LAST_SHIFT)

#define SOF_IPC4_GLB_PIPE_EXT_OBJ_ID_SHIFT	1
#define SOF_IPC4_GLB_PIPE_EXT_OBJ_ID_MASK	GENMASK(15, 1)
#define SOF_IPC4_GLB_PIPE_EXT_OBJ_ID(x)		((x) << SOF_IPC4_GLB_PIPE_EXT_OBJ_ID_SHIFT)

#define SOF_IPC4_GLB_PIPE_EXT_OBJ_WORDS_SHIFT	16
#define SOF_IPC4_GLB_PIPE_EXT_OBJ_WORDS_MASK	GENMASK(31, 16)
#define SOF_IPC4_GLB_PIPE_EXT_OBJ_WORDS(x)	((x) << SOF_IPC4_GLB_PIPE_EXT_OBJ_WORDS_SHIFT)

struct sof_ipc4_glb_pipe_ext_object {
	u32 header;
	u32 data[];
} __packed __aligned(4);

enum sof_ipc4_glb_pipe_ext_obj_id {
	SOF_IPC4_GLB_PIPE_DATA_ID_INVALID = 0,
	SOF_IPC4_GLB_PIPE_DATA_ID_MEM_DATA,
	SOF_IPC4_GLB_PIPE_DATA_ID_MAX = SOF_IPC4_GLB_PIPE_DATA_ID_MEM_DATA,
};

/* Pipeline memory configuration data object for ext_init object array */
struct sof_ipc4_glb_pipe_ext_obj_memory_data {
	u32 domain_id;		/* userspace domain ID */
	u32 stack_bytes;	/* stack size in bytes */
	u32 heap_bytes;		/* heap size in bytes */
} __packed __aligned(4);

/** @}*/

#endif
